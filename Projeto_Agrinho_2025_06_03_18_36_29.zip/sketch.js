function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let sunAngle = 0; //variaveis para o movimento do sol e do carro
let carX = 600;

function setup() { 
  //Cria o canvas de 800x400 pixels
  createCanvas(800, 400);
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Céu noturno suavemente
  if (sunAngle > PI) {
    background(30, 30, 60); // Céu escuro
  }

  // Linha divisória
  stroke(0);
  line(width / 2, 0, width / 2, height);

  // --------- Sol se movendo em arco ---------
  let sunX = map(sunAngle, 0, TWO_PI, 0, width);
  let sunY = 100 - 80 * sin(sunAngle);
  noStroke();
  fill(255, 204, 0);
  ellipse(sunX, sunY, 60, 60);
  sunAngle += 0.015;
  if (sunAngle > TWO_PI) {
    sunAngle = 0;
  }

  // --------- Campo (lado esquerdo) ---------
  noStroke();
  fill(34, 139, 34); // Grama
  rect(0, 300, width / 2, 100);

  fill(85, 170, 85); // Colinas
  ellipse(150, 300, 300, 200);
  ellipse(250, 300, 250, 150);

  drawTree(100, 260);
  drawTree(200, 280);
  drawTree(300, 270);

  // --------- Cidade (lado direito) ---------
  drawBuildings();
  drawMovingCar();

  // Título
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("Campo", width / 4, 30);
  text("Cidade", 3 * width / 4.5, 30);
}

function drawTree(x, y) {
  fill(139, 69, 19);
  rect(x, y, 20, 40);
  fill(34, 139, 34);
  ellipse(x + 10, y, 50, 50);
}

function drawBuildings() {
  let baseY = 300;
  fill(100);
  rect(420, baseY - 100, 60, 100);
  rect(500, baseY - 150, 50, 150);
  rect(570, baseY - 120, 70, 120);
  rect(660, baseY - 180, 60, 180);
  rect(740, baseY - 90, 40, 90);

  fill(255, 255, 0);
  for (let x = 420; x < 800; x += 60) {
    for (let y = 220; y < 300; y += 20) {
      rect(x + 10, y, 10, 10);
    }
  }
}

function drawMovingCar() {
  fill(255, 0, 0);
  rect(carX, 310, 60, 20);
  fill(0);
  ellipse(carX + 10, 330, 15, 15);
  ellipse(carX + 40, 330, 15, 15);

  // Movimento do carro
  carX += 1.8;
  if (carX > width) {
    carX = width / 2; // Reinicia da metade da cidade
  }
}
